<?php

/**
 * @property int $collection
 * @property int $resource
 * @property int $menuindex
 *
 * @property CollectionContainer $Collection
 * @property CollectionSetting $CollectionSetting
 * @property modResource $Resource
 *
 * @package collections
 */
class CollectionSelection extends xPDOObject
{
}
