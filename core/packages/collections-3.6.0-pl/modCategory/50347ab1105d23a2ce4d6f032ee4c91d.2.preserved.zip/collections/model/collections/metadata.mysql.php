<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'CollectionContainer',
  ),
  'CollectionContainer' => 
  array (
    0 => 'SelectionContainer',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'CollectionSetting',
    1 => 'CollectionTemplate',
    2 => 'CollectionTemplateColumn',
  ),
  'xPDOObject' => 
  array (
    0 => 'CollectionResourceTemplate',
    1 => 'CollectionSelection',
  ),
);