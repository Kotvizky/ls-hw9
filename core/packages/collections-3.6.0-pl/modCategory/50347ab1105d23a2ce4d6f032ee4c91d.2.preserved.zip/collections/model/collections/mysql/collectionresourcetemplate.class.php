<?php
/**
 * @package collections
 */
require_once(strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/collectionresourcetemplate.class.php');

class CollectionResourceTemplate_mysql extends CollectionResourceTemplate
{
}
